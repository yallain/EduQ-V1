Save du 15 09 2023 - fin apres midi

15 09 2023
Modification du baud en 19200 ok
modifier des programmes Python pour afficher dans le bon sens les registres recu ok
Laison serie Valider ok
les coicidence module a 2 pulse semblent bon .
Coincidence module à 3 entrées ok apres modife module pulse count

TO DO
Faire en sorte que le reset de datatrigger ne reste que 1 cycle d'horle de clk?

envoie de 10 registres de 32 bits

Header
CountPulseA
CountPulseB
CountPulseC
CountPulseD
CountCoincidence AB
CountCoincidence AC
CountCoincidence DB
CountCoincidence DC
CountCoincidence ABC


Todo : Datatrigger est a 1 pendant 1 cycles d'horloge de clkBaud donc les compteurs de Pulse et de coincidence ne "comptent" pas pendant 50 MicroSeconde -> Perte de pulse et de coincidence pendant cette fenetre -> voir si améliorable


Référence de la mémoire à choisir pour mettre le .bin dans le FPGA au reboot (sans passer par la programmation via JTAG)
s25fl128sxxxxxx0-spi-x1_x2_x4

Version du 11 09 

Etrange : Modification de l'ordre des counteurs de pulse D, C et B et A (dans le lancement des modules) et le compteur D ne s'incremente plus pour rien... ??

Warning a voir 
[Vivado 12-23575] Critical violations of the methodology design rules detected. Critical violations may contribute to timing failures or cause functional issues in hardware. Run report_methodology for more information.
Cette version est la plus fiable pour le moment

